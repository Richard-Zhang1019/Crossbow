//! 核心实体与 schema 版本化。
//!
//! 升级不丢配置的两条底线：
//! 1. 任何 schema 变更必须带 `migrate` 分支与迁移测试；
//! 2. 旧 schema 写入前自动快照（见 `store::Store::save`）。

use crate::emoji::default_flag_emoji;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

/// 当前存储 schema 版本。每次不兼容变更 +1，并在 `migrate` 中补一条迁移。
pub const SCHEMA_VERSION: u32 = 2;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ProfileKind {
    /// 远程订阅。
    Remote,
    /// 本地文件/手写配置。
    Local,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Profile {
    pub id: String,
    pub name: String,
    pub kind: ProfileKind,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub url: Option<String>,
    /// 原始订阅内容（Clash YAML / mihomo YAML）。
    #[serde(default)]
    pub content: String,
    /// 自动更新间隔（分钟），0 = 关闭。
    #[serde(default)]
    pub update_interval_min: u32,
    /// 挂载的覆写链，按序应用。
    #[serde(default)]
    pub override_ids: Vec<String>,
    #[serde(default)]
    pub last_updated: Option<u64>,
    /// 订阅流量信息（来自 `subscription-userinfo` 响应头），本地配置为空。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub traffic: Option<TrafficInfo>,
    /// 最近一次（含自动）订阅更新结果；旧数据无此字段，缺省 None。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub last_update: Option<UpdateOutcome>,
}

/// 一次订阅更新的结果（成功或失败）。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct UpdateOutcome {
    pub ok: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub changes: Option<NodeChanges>,
    /// 失败原因等补充信息。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub detail: Option<String>,
    /// Unix 秒。
    pub at: u64,
}

/// Counts only: never persist server credentials in update summaries.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NodeChanges {
    pub added: usize,
    pub removed: usize,
    pub changed: usize,
}

/// 机场订阅的流量/到期信息。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
pub struct TrafficInfo {
    pub upload: u64,
    pub download: u64,
    pub total: u64,
    /// Unix 秒；0 表示未知。
    #[serde(default)]
    pub expire: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum OverrideKind {
    /// YAML 顶层合并补丁。
    Merge,
    /// JS 脚本覆写：`function main(config) { ...; return config; }`。
    Script,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OverrideDef {
    pub id: String,
    pub name: String,
    pub kind: OverrideKind,
    pub enabled: bool,
    /// merge 补丁内容（YAML）；script 覆写为 JS 源码。
    pub content: String,
    /// 最近一次执行失败的报错（渲染链记录）；旧数据缺省 None。
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub last_error: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Engine {
    /// mihomo（原 Clash.Meta），macOS 默认。
    Mihomo,
    /// sing-box，macOS 备选 / iOS 唯一。
    SingBox,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EngineConfig {
    #[serde(default = "default_engine")]
    pub engine: Engine,
    /// stable / alpha 通道（M1 引入双通道下载）。
    #[serde(default)]
    pub channel: String,
    #[serde(default = "default_mixed_port")]
    pub mixed_port: u16,
    #[serde(default)]
    pub allow_lan: bool,
    /// 节点旗帜补全（按地区关键词给节点名加国旗前缀）。
    #[serde(default = "default_flag_emoji")]
    pub flag_emoji: bool,
    /// #532：统一延迟——mihomo 测延迟扣除握手开销，跨协议数字可比。
    #[serde(default = "default_unified_delay")]
    pub unified_delay: bool,
    /// TUN 模式：内核创建 utun 虚拟网卡接管全局流量（macOS 需特权服务）。
    #[serde(default)]
    pub tun_enable: bool,
    /// Linux only: preserve a verified WireGuard split tunnel when starting TUN.
    #[serde(default)]
    pub linux_wireguard_coexist: bool,
}

fn default_engine() -> Engine {
    Engine::Mihomo
}

fn default_unified_delay() -> bool {
    true
}

fn default_mixed_port() -> u16 {
    7897
}

impl Default for EngineConfig {
    fn default() -> Self {
        Self {
            engine: Engine::Mihomo,
            channel: "stable".into(),
            mixed_port: default_mixed_port(),
            allow_lan: false,
            flag_emoji: default_flag_emoji(),
            unified_delay: true,
            tun_enable: false,
            linux_wireguard_coexist: false,
        }
    }
}

/// 持久化的顶层存储。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StoreSchema {
    /// 缺省视为 v0（早期手编文件），由 `migrate` 补齐。
    #[serde(default)]
    pub schema_version: u32,
    pub profiles: Vec<Profile>,
    pub overrides: Vec<OverrideDef>,
    #[serde(default)]
    pub engine: EngineConfig,
    /// 当前激活的 profile id。
    #[serde(default)]
    pub active_profile: Option<String>,
    /// v2：界面设置（主题/语言）。
    #[serde(default)]
    pub ui: UiSettings,
    /// v3：日志本地保存设置。
    #[serde(default)]
    pub logs: LogSettings,
    /// v3：应用更新设置。
    #[serde(default)]
    pub update: UpdateSettings,
    /// v3：SSID 网络场景（#566）。serde default 兜底且不推进
    /// SCHEMA_VERSION——与 ui/logs/update 同一先例，保证旧版本程序
    /// （自动更新回滚）读新文件不被 SchemaTooNew 拒绝。
    #[serde(default)]
    pub scenes: NetworkScenes,
    /// v3：按进程分流规则（#570）。渲染时前插到订阅规则之前；目标策略
    /// 失效（订阅更新后组名消失）的规则在渲染时防御性丢弃。
    #[serde(default)]
    pub process_rules: Vec<ProcessRule>,
    #[serde(default)]
    pub user_rules: Vec<crate::user_rules::UserRule>,
    /// Application-managed rule subscriptions and last-good local cache (#571).
    #[serde(default)]
    pub rule_sets: Vec<crate::rule_sets::RuleSet>,
    /// v3：DNS 配置（#598）。沿用订阅为默认，零行为变更；自定义模式在
    /// 渲染层注入用户上游（用户设置 > 覆写 > 订阅 > TUN 运行时注入）。
    #[serde(default)]
    pub dns: crate::dns_settings::DnsSettings,
}

/// SSID 网络场景（#566）：Wi-Fi 名称 → 进入该网络时的接管动作。
/// 动作值只认 `"direct"`（直连）与 `"proxy"`（代理）；未知值按未配置
/// 处理（不干预），防止旧/异构数据破坏启动。
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct NetworkScenes {
    #[serde(default)]
    pub rules: BTreeMap<String, String>,
}

impl NetworkScenes {
    /// 当前 SSID 命中的动作；未命中、SSID 未知或动作值非法时为 None。
    pub fn target_action(&self, ssid: Option<&str>) -> Option<&str> {
        let ssid = ssid?;
        let action = self.rules.get(ssid)?;
        match action.as_str() {
            "direct" | "proxy" => Some(action),
            _ => None,
        }
    }
}

/// 一条按进程分流规则（#570）：`process` 为内核连接元数据里的进程名
/// （与连接页展示同名）；`target` 为 DIRECT / REJECT / 当前订阅的
/// proxy-groups 名。id 是前端 key 与命令句柄。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProcessRule {
    pub id: String,
    pub process: String,
    pub target: String,
}

/// 应用更新设置（#28）。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct UpdateSettings {
    /// 自动检查更新（默认开：启动 30s 后 + 每 6h）
    #[serde(default = "default_true")]
    pub auto_check: bool,
    /// 自动下载新版本（默认关；下载完成后提示重启安装）
    #[serde(default)]
    pub auto_download: bool,
}

impl Default for UpdateSettings {
    fn default() -> Self {
        Self {
            auto_check: default_true(),
            auto_download: false,
        }
    }
}

/// 日志本地保存设置（#29）：按天落盘 + 保留天数自动清理。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct LogSettings {
    /// 本地保存开关（默认开；关闭只停止写入，不删除已存文件）
    #[serde(default = "default_true")]
    pub save_enabled: bool,
    /// 保留天数：1/3/5/7/15/30（默认 7），超出自动删除
    #[serde(default = "default_retention_days")]
    pub retention_days: u32,
}

fn default_true() -> bool {
    true
}

fn default_retention_days() -> u32 {
    7
}

impl Default for LogSettings {
    fn default() -> Self {
        Self {
            save_enabled: default_true(),
            retention_days: default_retention_days(),
        }
    }
}

/// 界面设置（v2 加入）。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct UiSettings {
    /// system / light / dark
    #[serde(default = "default_theme")]
    pub theme: String,
    /// zh / en
    #[serde(default = "default_lang")]
    pub lang: String,
    /// 轻量模式：关窗即交接退出（保留内核与系统代理）。
    #[serde(default)]
    pub lightweight_close: bool,
    /// 深链导入订阅前弹原生确认框（#420）。安全默认开：crossbow:// 可被
    /// 任意程序触发，无确认等于把路由决策链暴露给外部输入。
    #[serde(default = "default_true")]
    pub deep_link_import_confirm: bool,
}

fn default_theme() -> String {
    "system".into()
}

fn default_lang() -> String {
    // 英文优先（#353/#355）：新安装默认英文；已持久化过语言设置的旧用户保持原值
    "en".into()
}

impl Default for UiSettings {
    fn default() -> Self {
        Self {
            theme: default_theme(),
            lang: default_lang(),
            lightweight_close: false,
            deep_link_import_confirm: true,
        }
    }
}

impl Default for StoreSchema {
    fn default() -> Self {
        Self {
            schema_version: SCHEMA_VERSION,
            profiles: Vec::new(),
            overrides: Vec::new(),
            engine: EngineConfig::default(),
            active_profile: None,
            ui: UiSettings::default(),
            logs: LogSettings::default(),
            update: UpdateSettings::default(),
            scenes: NetworkScenes::default(),
            process_rules: Vec::new(),
            user_rules: Vec::new(),
            rule_sets: Vec::new(),
            dns: Default::default(),
        }
    }
}

impl StoreSchema {
    /// 老版本数据迁移到当前版本。写入前由 `Store::save` 调用。
    pub fn migrate(&mut self) {
        // v0 → v1：v0 是无 schema_version 字段的早期手编文件。
        if self.schema_version < 1 {
            // 首个版本：补齐 engine 默认值即可（serde default 已兜底）。
            self.schema_version = 1;
        }
        // v1 → v2：新增 ui 设置（serde default 已兜底，仅需推进版本号）。
        if self.schema_version < 2 {
            self.schema_version = 2;
        }
    }

    pub fn profile(&self, id: &str) -> Option<&Profile> {
        self.profiles.iter().find(|p| p.id == id)
    }

    /// 新增 Profile；id 冲突报错。
    pub fn add_profile(&mut self, profile: Profile) -> Result<(), String> {
        if self.profile(&profile.id).is_some() {
            return Err(format!("profile {} already exists", profile.id));
        }
        if self.active_profile.is_none() {
            self.active_profile = Some(profile.id.clone());
        }
        self.profiles.push(profile);
        Ok(())
    }

    /// 设为当前；不存在的 id 报错。
    pub fn set_active_profile(&mut self, id: &str) -> Result<(), String> {
        if self.profile(id).is_none() {
            return Err(format!("profile {id} not found"));
        }
        self.active_profile = Some(id.to_string());
        Ok(())
    }

    /// 删除 Profile 并清理引用（当前激活、其他档案的覆写链不受影响）。
    pub fn remove_profile(&mut self, id: &str) -> Result<(), String> {
        let before = self.profiles.len();
        self.profiles.retain(|p| p.id != id);
        if self.profiles.len() == before {
            return Err(format!("profile {id} not found"));
        }
        if self.active_profile.as_deref() == Some(id) {
            self.active_profile = self.profiles.first().map(|p| p.id.clone());
        }
        Ok(())
    }

    /// 记录覆写执行错误；不存在的 id 忽略。
    pub fn set_override_error(&mut self, id: &str, error: Option<String>) {
        for o in self.overrides.iter_mut() {
            if o.id == id {
                o.last_error = error.clone();
            }
        }
    }

    /// 清除全部覆写错误（渲染链成功后调用）。
    pub fn clear_override_errors(&mut self) {
        for o in self.overrides.iter_mut() {
            o.last_error = None;
        }
    }

    /// 记录档案更新结果；不存在的 id 报错。
    pub fn set_profile_outcome(&mut self, id: &str, outcome: UpdateOutcome) -> Result<(), String> {
        let p = self
            .profiles
            .iter_mut()
            .find(|p| p.id == id)
            .ok_or_else(|| format!("profile {id} not found"))?;
        p.last_update = Some(outcome);
        Ok(())
    }

    /// 更新档案内容（订阅刷新）。不存在的 id 报错。
    pub fn update_profile_content(
        &mut self,
        id: &str,
        content: String,
        last_updated: u64,
        traffic: Option<TrafficInfo>,
    ) -> Result<(), String> {
        let p = self
            .profiles
            .iter_mut()
            .find(|p| p.id == id)
            .ok_or_else(|| format!("profile {id} not found"))?;
        p.content = content;
        p.last_updated = Some(last_updated);
        p.traffic = traffic;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn profile(id: &str) -> Profile {
        Profile {
            id: id.into(),
            name: format!("name-{id}"),
            kind: ProfileKind::Remote,
            url: None,
            content: String::new(),
            update_interval_min: 0,
            override_ids: Vec::new(),
            last_updated: None,
            traffic: None,
            last_update: None,
        }
    }

    #[test]
    fn v0_store_migrates_to_current() {
        let mut data: StoreSchema =
            serde_json::from_str(r#"{"profiles":[],"overrides":[]}"#).unwrap();
        assert_eq!(data.schema_version, 0);
        data.migrate();
        assert_eq!(data.schema_version, SCHEMA_VERSION);
        assert_eq!(data.engine.mixed_port, 7897);
        assert_eq!(data.ui.theme, "system");
    }

    #[test]
    fn profile_without_last_update_field_loads() {
        let raw = r#"{"id":"a","name":"n","kind":"remote","content":""}"#;
        let p: Profile = serde_json::from_str(raw).unwrap();
        assert!(p.last_update.is_none());
    }

    #[test]
    fn v1_store_migrates_to_v2() {
        let mut data: StoreSchema = serde_json::from_str(
            r#"{"schema_version":1,"profiles":[],"overrides":[],"engine":{},"active_profile":null}"#,
        )
        .unwrap();
        data.migrate();
        assert_eq!(data.schema_version, 2);
        assert_eq!(data.ui, UiSettings::default());
        assert!(!data.engine.linux_wireguard_coexist);
    }

    #[test]
    fn future_schema_is_rejected_upstream() {
        let data: StoreSchema =
            serde_json::from_str(r#"{"schema_version":99,"profiles":[],"overrides":[]}"#).unwrap();
        // Store::load 负责拒绝；这里只断言反序列化本身不丢信息。
        assert_eq!(data.schema_version, 99);
    }

    #[test]
    fn add_first_profile_makes_it_active() {
        let mut s = StoreSchema::default();
        s.add_profile(profile("a")).unwrap();
        assert_eq!(s.active_profile.as_deref(), Some("a"));
        s.add_profile(profile("b")).unwrap();
        assert_eq!(s.active_profile.as_deref(), Some("a"));
        assert!(s.add_profile(profile("a")).is_err());
    }

    #[test]
    fn remove_active_profile_falls_back_to_first() {
        let mut s = StoreSchema::default();
        s.add_profile(profile("a")).unwrap();
        s.add_profile(profile("b")).unwrap();
        s.set_active_profile("b").unwrap();
        s.remove_profile("b").unwrap();
        assert_eq!(s.active_profile.as_deref(), Some("a"));
        assert!(s.remove_profile("zz").is_err());
    }

    #[test]
    fn update_content_sets_timestamp_and_traffic() {
        let mut s = StoreSchema::default();
        s.add_profile(profile("a")).unwrap();
        s.update_profile_content(
            "a",
            "proxies: []".into(),
            42,
            Some(TrafficInfo {
                upload: 1,
                download: 2,
                total: 10,
                expire: 0,
            }),
        )
        .unwrap();
        let p = s.profile("a").unwrap();
        assert_eq!(p.last_updated, Some(42));
        assert_eq!(p.traffic.unwrap().total, 10);
    }
    #[test]
    fn network_scenes_match_only_known_actions() {
        // #566：SSID 命中、未命中、SSID 未知、动作值非法各走各的分支。
        let mut s = StoreSchema::default();
        s.scenes.rules.insert("Home".into(), "direct".into());
        s.scenes.rules.insert("Office".into(), "proxy".into());
        s.scenes.rules.insert("Broken".into(), "turbo".into());
        assert_eq!(s.scenes.target_action(Some("Home")), Some("direct"));
        assert_eq!(s.scenes.target_action(Some("Office")), Some("proxy"));
        assert_eq!(s.scenes.target_action(Some("Broken")), None);
        assert_eq!(s.scenes.target_action(Some("Cafe")), None);
        assert_eq!(s.scenes.target_action(None), None);
    }

    #[test]
    fn scenes_section_defaults_and_roundtrips() {
        use crate::Store;
        // serde default 兜底：旧文件（无 scenes 字段）解析成功且不推版本号。
        let legacy =
            Store::load_str(r#"{"schema_version":2,"profiles":[],"overrides":[]}"#).unwrap();
        assert!(legacy.scenes.rules.is_empty());
        let mut s = StoreSchema::default();
        s.scenes.rules.insert("Home".into(), "proxy".into());
        let raw = serde_json::to_string(&s).unwrap();
        let back = Store::load_str(&raw).unwrap();
        assert_eq!(back.scenes.target_action(Some("Home")), Some("proxy"));
    }
}
