//! mihomo External Controller 客户端（127.0.0.1 TCP + Bearer secret）。
//!
//! REST：模式切换、代理组快照、节点选择、组/单节点延迟测速。
//! WS：traffic/logs/connections 在 ws_bridge（Rust 侧节流聚合）。

use std::collections::BTreeMap;
use std::time::Duration;

use serde::Serialize;

pub const MODES: [&str; 3] = ["direct", "rule", "global"];
/// 测速目标 URL（204 无正文，机场/内核通用基准）。
const BENCHMARK_URL: &str = "http://www.gstatic.com/generate_204";
/// #491：主目标超时后的复核目标——与主目标不同运营方（Google vs Cloudflare），
/// 保留独立目标结果，避免把单目标异常泛化为节点故障。
const BENCHMARK_URL_REVIEW: &str = "https://cp.cloudflare.com/generate_204";
const BENCHMARK_URL_HTTPS: &str = "https://www.gstatic.com/generate_204";
pub(crate) const NODE_DELAY_REQUEST_BUDGET: Duration = Duration::from_secs(7);

#[derive(Debug, Clone, Serialize)]
pub struct NodeView {
    pub name: String,
    pub kind: String,
    pub alive: bool,
    /// 最近一次测速延迟（ms）；未测/失败为 None。
    pub delay_ms: Option<u64>,
}

#[derive(Debug, Clone, Serialize)]
pub struct GroupView {
    pub name: String,
    pub kind: String,
    /// 当前选中节点（Selector/URLTest 等）。
    pub now: Option<String>,
    /// URLTest 手动固定节点；空值表示由内核自动选择。
    pub fixed: Option<String>,
    pub nodes: Vec<NodeView>,
}

pub struct Controller {
    pub port: u16,
    pub secret: String,
}

/// 一次节点延迟采样：目标主/复核由 `reviewed` 标记。
#[derive(Debug, Clone, Serialize, serde::Deserialize)]
pub(crate) struct DelaySample {
    pub delay_ms: u64,
    pub reviewed: bool,
    pub target: String,
    pub tested_at_ms: u64,
    pub sample_count: u8,
}

#[derive(Debug)]
pub(crate) enum NodeDelayError {
    /// 内核对该目标的测速预算耗尽；本身不能证明节点故障。
    Timeout(String),
    /// 内核完成节点探测但失败（503 或零延迟）。
    Failed(String),
    /// 控制器传输失败（连不上内核 API）——不是节点故障，徽标需与
    /// 节点超时区分（#491）。
    Controller(String),
    Cancelled(String),
    Skipped(String),
}

impl NodeDelayError {
    fn from_request(node: &str, error: ureq::Error) -> Self {
        let details = format!("node delay {node}: {error}");
        match error {
            // 目标探测预算耗尽；与控制器传输错误分开。
            ureq::Error::Status(504, _) => Self::Timeout(details),
            // 连不上控制器 API：控制器/本地链路故障，不是节点故障。
            ureq::Error::Transport(_) => Self::Controller(details),
            ureq::Error::Status(503, _) => Self::Failed(details),
            ureq::Error::Status(404, _) => Self::Skipped(details),
            _ => Self::Controller(details),
        }
    }
}

impl std::fmt::Display for NodeDelayError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Timeout(details)
            | Self::Failed(details)
            | Self::Controller(details)
            | Self::Cancelled(details)
            | Self::Skipped(details) => f.write_str(details),
        }
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct OutboundInfo {
    pub mode: String,
    /// 最终出口节点名（组会解析到具体节点；DIRECT/REJECT 原样）。
    pub node: String,
    /// 出口节点最近一次测速延迟。
    pub delay_ms: Option<u64>,
    /// 决策链（规则目标组 → 出口）。
    pub chain: Vec<String>,
}

/// mihomo 的通用 history 混合所有测试 URL；复核值不能回流为主目标延迟。
fn comparable_delay(node: &serde_json::Value) -> Option<u64> {
    let extra = node.get("extra");
    let history = if let Some(primary) = extra.and_then(|extra| extra.get(BENCHMARK_URL)) {
        primary.get("history")
    } else if extra.is_some_and(|extra| extra.get(BENCHMARK_URL_REVIEW).is_some()) {
        None
    } else {
        node.get("history") // sing-box/旧控制器没有按 URL 分组时保留兼容。
    };
    history
        .and_then(|h| h.as_array())
        .and_then(|a| a.last())
        .and_then(|entry| entry.get("delay"))
        .and_then(|d| d.as_u64())
        .filter(|d| *d > 0)
}

impl Controller {
    fn agent() -> ureq::Agent {
        ureq::AgentBuilder::new()
            .try_proxy_from_env(false)
            .timeout(Duration::from_secs(5))
            .build()
    }

    /// 测速用的长超时 agent（组测速可能到 5s+）。
    fn slow_agent() -> ureq::Agent {
        ureq::AgentBuilder::new()
            .try_proxy_from_env(false)
            .timeout(Duration::from_secs(30))
            .build()
    }

    fn req_on(
        agent: &ureq::Agent,
        port: u16,
        secret: &str,
        method: &str,
        path: &str,
    ) -> ureq::Request {
        agent
            .request(method, &format!("http://127.0.0.1:{port}{path}"))
            .set("Authorization", &format!("Bearer {secret}"))
    }

    fn req(&self, method: &str, path: &str) -> ureq::Request {
        Self::req_on(&Self::agent(), self.port, &self.secret, method, path)
    }

    fn get_json(&self, path: &str) -> Result<serde_json::Value, String> {
        let resp = self
            .req("GET", path)
            .call()
            .map_err(|e| format!("GET {path}: {e}"))?;
        if resp.status() >= 400 {
            return Err(format!("GET {path}: HTTP {}", resp.status()));
        }
        let text = resp
            .into_string()
            .map_err(|e| format!("read {path}: {e}"))?;
        serde_json::from_str(&text).map_err(|e| format!("decode {path}: {e}"))
    }

    #[cfg(any(target_os = "macos", target_os = "windows", test))]
    pub fn tun_enabled(&self) -> Result<Option<bool>, String> {
        Ok(self.get_json("/configs")?["tun"]["enable"].as_bool())
    }

    /// The live device may differ from the configured auto-assigned name.
    /// Never infer ownership from the saved TUN switch or a shared IP range.
    #[cfg(any(target_os = "macos", target_os = "windows", test))]
    pub fn active_tun_device(&self) -> Result<Option<String>, String> {
        let config = self.get_json("/configs")?;
        let tun = &config["tun"];
        if tun["enable"].as_bool() != Some(true) {
            return Ok(None);
        }
        Ok(tun["device"]
            .as_str()
            .filter(|name| {
                if cfg!(target_os = "windows") {
                    *name == "Crossbow"
                } else {
                    name.strip_prefix("utun").is_some_and(|suffix| {
                        !suffix.is_empty() && suffix.bytes().all(|b| b.is_ascii_digit())
                    })
                }
            })
            .map(str::to_owned))
    }

    /// 切换运行模式（direct / rule / global）。运行时生效，不落盘。
    /// 热切换 TUN（PATCH /configs）：内核不重启，mihomo 运行时重建
    /// tun 栈。关 TUN 由此绕开「杀 root 内核 → 端口交接 → 重启探测」
    /// 整条链路（实测该链路 30s+ 且 root 内核杀不死时 bind 必失败）。
    /// 仅 mihomo 支持 tun 热更新；sing-box 的 clash_api 不支持。
    #[cfg(target_os = "macos")]
    pub fn patch_tun_enable(&self, enable: bool) -> Result<(), String> {
        let body = serde_json::to_vec(&serde_json::json!({
            "tun": { "enable": enable }
        }))
        .map_err(|e| e.to_string())?;
        let resp = self
            .req("PATCH", "/configs")
            .send_bytes(&body)
            .map_err(|e| format!("patch tun: {e}"))?;
        if resp.status() < 300 {
            Ok(())
        } else {
            Err(format!("patch tun: HTTP {}", resp.status()))
        }
    }

    /// 重载已经写好的配置文件，不杀进程。
    ///
    /// mihomo：`PUT /configs?force=true`。路径必须是本次 `-f` 用的 config.yaml，
    /// 它在工作目录内，不需要额外的 SAFE_PATHS。sing-box 的 clash_api 不走这里。
    pub fn reload_config(&self, path: &std::path::Path) -> Result<(), String> {
        let body = serde_json::to_vec(&serde_json::json!({
            "path": path.to_string_lossy(),
            "payload": ""
        }))
        .map_err(|e| e.to_string())?;
        let resp = Self::req_on(
            &Self::reload_agent(),
            self.port,
            &self.secret,
            "PUT",
            "/configs?force=true",
        )
        .send_bytes(&body)
        .map_err(|e| format!("reload config: {e}"))?;
        if resp.status() < 300 {
            Ok(())
        } else {
            Err(format!("reload config: HTTP {}", resp.status()))
        }
    }

    fn reload_agent() -> ureq::Agent {
        ureq::AgentBuilder::new()
            .try_proxy_from_env(false)
            .timeout(Duration::from_secs(60))
            .build()
    }

    pub fn patch_mode(&self, mode: &str) -> Result<(), String> {
        if !MODES.contains(&mode) {
            return Err(format!("unknown mode: {mode}"));
        }
        let body =
            serde_json::to_vec(&serde_json::json!({ "mode": mode })).map_err(|e| e.to_string())?;
        let resp = self
            .req("PATCH", "/configs")
            .send_bytes(&body)
            .map_err(|e| format!("patch mode: {e}"))?;
        if resp.status() < 300 {
            Ok(())
        } else {
            Err(format!("patch mode: HTTP {}", resp.status()))
        }
    }

    /// 代理组快照：过滤出含节点的组（Selector/URLTest/Fallback/LoadBalance），
    /// 组内成员映射为 NodeView（延迟取 history 最新一条）。
    pub fn groups(&self) -> Result<Vec<GroupView>, String> {
        let v = self.get_json("/proxies")?;
        let all = v
            .get("proxies")
            .and_then(|p| p.as_object())
            .ok_or("malformed /proxies")?;
        let mut groups = Vec::new();
        for (name, node) in all {
            let Some(members) = node.get("all").and_then(|a| a.as_array()) else {
                continue; // 普通节点
            };
            let kind = node
                .get("type")
                .and_then(|t| t.as_str())
                .unwrap_or("")
                .to_string();
            if matches!(kind.as_str(), "Compatible" | "Direct" | "Reject" | "Pass") {
                continue;
            }
            let now = node.get("now").and_then(|n| n.as_str()).map(String::from);
            let fixed = node
                .get("fixed")
                .and_then(|n| n.as_str())
                .filter(|n| !n.is_empty())
                .map(String::from);
            let nodes = members
                .iter()
                .filter_map(|m| m.as_str())
                .map(|m| {
                    let child = all.get(m);
                    let delay = child.and_then(comparable_delay);
                    // 组嵌组时延迟取组内当前节点不可得，显示为未测即可
                    NodeView {
                        name: m.to_string(),
                        kind: child
                            .and_then(|c| c.get("type"))
                            .and_then(|t| t.as_str())
                            .unwrap_or("")
                            .to_string(),
                        alive: child
                            .and_then(|c| c.get("alive"))
                            .and_then(|a| a.as_bool())
                            .unwrap_or(true),
                        delay_ms: delay,
                    }
                })
                .collect();
            groups.push(GroupView {
                name: name.clone(),
                kind,
                now,
                fixed,
                nodes,
            });
        }
        // 稳定排序：GLOBAL 放最后，其余按名称
        groups.sort_by(|a, b| {
            let ga = (a.name == "GLOBAL") as u8;
            let gb = (b.name == "GLOBAL") as u8;
            ga.cmp(&gb).then(a.name.cmp(&b.name))
        });
        Ok(groups)
    }

    /// 所有页面/托盘选择共用此入口。切回 URLTest 子组时先解除旧固定，
    /// 在 URLTest 本身选择成员则保留内核的手动固定语义。
    pub fn select_proxy(&self, group: &str, name: &str) -> Result<(), String> {
        let source = self.get_json(&build_path(&["/proxies", group]))?;
        if !source["all"]
            .as_array()
            .is_some_and(|members| members.iter().any(|n| n.as_str() == Some(name)))
        {
            return Err("node is not a member of this group".into());
        }
        if source["type"].as_str() == Some("Selector") {
            let target = self.get_json(&build_path(&["/proxies", name]))?;
            if target["type"].as_str() == Some("URLTest")
                && target["fixed"].as_str().is_some_and(|n| !n.is_empty())
            {
                self.reset_proxy_selection(name)?;
            }
        }
        let path = build_path(&["/proxies", group]);
        let body =
            serde_json::to_vec(&serde_json::json!({ "name": name })).map_err(|e| e.to_string())?;
        let resp = self
            .req("PUT", &path)
            .send_bytes(&body)
            .map_err(|e| format!("select {group}: {e}"))?;
        if resp.status() < 300 {
            Ok(())
        } else {
            Err(format!("select {group}: HTTP {}", resp.status()))
        }
    }

    /// mihomo DELETE 清除固定（同时清理内核缓存）；不能用 PUT "" 代替。
    /// 非自动组、未提供 fixed 的兼容内核不发送 DELETE。
    pub fn reset_proxy_selection(&self, group: &str) -> Result<(), String> {
        let path = build_path(&["/proxies", group]);
        let current = self.get_json(&path)?;
        if current["type"].as_str() != Some("URLTest") || !current["fixed"].is_string() {
            return Err("this group does not support restoring automatic selection".into());
        }
        if current["fixed"].as_str() == Some("") {
            return Ok(());
        }
        self.req("DELETE", &path)
            .call()
            .map_err(|e| format!("restore automatic selection: {e}"))?;
        Ok(())
    }

    /// 组测速：mihomo 内部并发探测组内全部节点，返回 {节点: 延迟ms}（失败者缺席）。
    pub fn test_group_delay(&self, group: &str) -> Result<BTreeMap<String, u64>, String> {
        let path = format!(
            "{}?url={}&timeout=5000",
            build_path(&["/group", group, "delay"]),
            BENCHMARK_URL
        );
        let agent = Self::slow_agent();
        let resp = Self::req_on(&agent, self.port, &self.secret, "GET", &path)
            .call()
            .map_err(|e| format!("group delay {group}: {e}"))?;
        if resp.status() >= 400 {
            return Err(format!("group delay {group}: HTTP {}", resp.status()));
        }
        let text = resp.into_string().map_err(|e| e.to_string())?;
        let v: serde_json::Value = serde_json::from_str(&text).map_err(|e| e.to_string())?;
        let mut out = BTreeMap::new();
        if let Some(obj) = v.as_object() {
            for (k, d) in obj {
                if let Some(ms) = d.as_u64().filter(|delay| *delay > 0) {
                    out.insert(k.clone(), ms);
                }
            }
        }
        Ok(out)
    }

    /// 控制器版本信息（就绪/诊断用）。
    pub fn version(&self) -> Result<String, String> {
        let v = self.get_json("/version")?;
        Ok(v.get("version")
            .and_then(|x| x.as_str())
            .unwrap_or("unknown")
            .to_string())
    }

    /// #603：经内核自己的解析器查询 DNS（Clash 兼容 `GET /dns/query`）。
    ///
    /// 返回 DNS 报文 JSON（Status/Answer），不含上游与缓存字段——调用方不得
    /// 从 TTL 反推缓存命中。
    pub fn dns_query(&self, name: &str, record_type: &str) -> Result<serde_json::Value, String> {
        use std::io::Read;
        const LIMIT: u64 = 256 * 1024;
        let response = self
            .req("GET", &dns_query_path(name, record_type))
            .call()
            .map_err(|error| {
                if matches!(&error, ureq::Error::Transport(_))
                    && error.to_string().to_ascii_lowercase().contains("timed out")
                {
                    "DNS query timeout: controller round trip exceeded its budget".to_string()
                } else {
                    "DNS query failed: controller request failed".to_string()
                }
            })?;
        let mut bytes = Vec::new();
        response
            .into_reader()
            .take(LIMIT + 1)
            .read_to_end(&mut bytes)
            .map_err(|_| "DNS query response read failed".to_string())?;
        if bytes.len() as u64 > LIMIT {
            return Err("DNS query response too large".into());
        }
        serde_json::from_slice(&bytes).map_err(|_| "DNS query response is not valid JSON".into())
    }

    /// 当前出口：规则模式取最后一条 MATCH 规则的目标组并解析其当前节点；
    /// 全局模式取 GLOBAL.now。`final_fallback` 用于 /rules 里没有 MATCH
    /// 规则的内核（sing-box clash api 不合成 MATCH）：读配置的 route.final。
    pub fn current_outbound(&self, final_fallback: Option<&str>) -> Result<OutboundInfo, String> {
        self.outbound_snapshot(final_fallback)
            .map(|(outbound, _)| outbound)
    }

    fn outbound_snapshot(
        &self,
        final_fallback: Option<&str>,
    ) -> Result<(OutboundInfo, Option<String>), String> {
        let configs = self.get_json("/configs")?;
        let mode = configs
            .get("mode")
            .and_then(|m| m.as_str())
            .unwrap_or("rule")
            .to_string();
        let proxies_v = self.get_json("/proxies")?;
        let all = proxies_v
            .get("proxies")
            .and_then(|p| p.as_object())
            .ok_or("malformed /proxies")?;

        // 沿 now 链下钻到具体节点，附带其最新延迟。now 为空串（如测速未完成
        // 的 urltest）时停在当前层，不能把链路截断成空名。
        let resolve = |start: &str| -> (String, Option<u64>) {
            let mut cur = start.to_string();
            for _ in 0..6 {
                let Some(node) = all.get(&cur) else { break };
                match node.get("now").and_then(|n| n.as_str()) {
                    Some(next) if !next.is_empty() => cur = next.to_string(),
                    Some(_) => break,
                    None => {
                        let delay = comparable_delay(node);
                        return (cur, delay);
                    }
                }
            }
            (cur, None)
        };

        let (node, delay_ms, chain) = if mode == "global" {
            let (n, d) = resolve("GLOBAL");
            (n, d, vec!["GLOBAL".to_string()])
        } else {
            let rules = self.get_json("/rules")?;
            let match_target = rules
                .get("rules")
                .and_then(|r| r.as_array())
                .and_then(|arr| {
                    arr.iter().rev().find(|r| {
                        r.get("type")
                            .and_then(|t| t.as_str())
                            .map(|t| t.eq_ignore_ascii_case("Match"))
                            .unwrap_or(false)
                    })
                })
                .and_then(|r| r.get("proxy"))
                .and_then(|p| p.as_str())
                .map(String::from);
            let target = match_target
                .or_else(|| final_fallback.map(String::from))
                .unwrap_or_else(|| "DIRECT".to_string());
            if target == "DIRECT" || target == "REJECT" {
                (target.clone(), None, vec![target])
            } else {
                let (n, d) = resolve(&target);
                (n, d, vec![target])
            }
        };
        let kind = all.get(&node).and_then(|proxy| {
            // A group with no resolved member does not identify a concrete exit.
            if proxy["all"].is_array() {
                return None;
            }
            proxy["type"].as_str().map(str::to_owned)
        });
        Ok((
            OutboundInfo {
                mode,
                node,
                delay_ms,
                chain,
            },
            kind,
        ))
    }

    /// `None` means the controller did not identify a testable proxy or could
    /// not complete the test. Only two explicit outbound failures mean offline.
    pub(crate) fn probe_config_outbound(&self, targets: [&str; 2]) -> Option<bool> {
        let first = self.probe_config_outbound_once(targets[0]);
        if first != Some(false) {
            return first;
        }
        // Resolve again so an automatic group's new selection gets a chance.
        self.probe_config_outbound_once(targets[1])
    }

    fn probe_config_outbound_once(&self, target: &str) -> Option<bool> {
        let (outbound, kind) = self.outbound_snapshot(None).ok()?;
        if !matches!(outbound.mode.as_str(), "rule" | "global")
            || matches!(
                kind.as_deref()?,
                "Direct" | "Reject" | "RejectDrop" | "Compatible" | "Pass" | "Dns" | "DNS"
            )
        {
            return None;
        }
        // A request to the mixed port can hit a DIRECT rule for the probe host.
        // Ask mihomo to issue an HTTPS request through the selected node itself.
        let query = url::form_urlencoded::Serializer::new(String::new())
            .append_pair("url", target)
            .append_pair("timeout", "3000")
            .finish();
        let path = format!(
            "{}?{query}",
            build_path(&["/proxies", &outbound.node, "delay"])
        );
        match self.req("GET", &path).call() {
            Ok(response) => {
                let body: serde_json::Value =
                    serde_json::from_reader(response.into_reader()).ok()?;
                body["delay"]
                    .as_u64()
                    .filter(|delay| *delay > 0)
                    .map(|_| true)
            }
            Err(ureq::Error::Status(503 | 504, _)) => Some(false),
            Err(_) => None,
        }
    }

    /// 断开单条连接。
    pub fn close_connection(&self, id: &str) -> Result<(), String> {
        let resp = self
            .req("DELETE", &format!("/connections/{id}"))
            .call()
            .map_err(|e| format!("close connection: {e}"))?;
        if resp.status() < 300 {
            Ok(())
        } else {
            Err(format!("close connection: HTTP {}", resp.status()))
        }
    }

    /// 单节点测速：仅测试消费（#564 命令删后）；生产走
    /// `measure_node_delay_with_review`（结构化结果）。
    #[cfg(test)]
    pub fn test_node_delay(&self, node: &str) -> Result<u64, String> {
        self.measure_node_delay(node)
            .map_err(|error| error.to_string())
    }

    /// A gateway timeout from the controller is a completed node test.
    /// A transport failure talking to the controller is a different failure.
    #[cfg(test)]
    pub(crate) fn measure_node_delay(&self, node: &str) -> Result<u64, NodeDelayError> {
        self.measure_via(node, BENCHMARK_URL)
    }

    #[cfg(test)]
    fn measure_via(&self, node: &str, url: &str) -> Result<u64, NodeDelayError> {
        self.measure_via_with_timeout(node, url, Duration::from_secs(30))
    }

    fn measure_via_with_timeout(
        &self,
        node: &str,
        url: &str,
        timeout: Duration,
    ) -> Result<u64, NodeDelayError> {
        let path = format!(
            "{}?url={url}&timeout=5000",
            build_path(&["/proxies", node, "delay"])
        );
        let agent = ureq::AgentBuilder::new()
            .try_proxy_from_env(false)
            .redirects(0)
            .timeout(timeout)
            .build();
        let resp = Self::req_on(&agent, self.port, &self.secret, "GET", &path)
            .call()
            .map_err(|error| NodeDelayError::from_request(node, error))?;
        if resp.status() != 200 {
            return Err(NodeDelayError::Controller(format!(
                "node delay {node}: HTTP {}",
                resp.status()
            )));
        }
        let text = resp
            .into_string()
            .map_err(|error| NodeDelayError::Controller(error.to_string()))?;
        let v: serde_json::Value = serde_json::from_str(&text)
            .map_err(|error| NodeDelayError::Controller(error.to_string()))?;
        let delay = v.get("delay").and_then(|d| d.as_u64()).ok_or_else(|| {
            NodeDelayError::Controller(format!("node delay {node}: no delay field"))
        })?;
        if delay == 0 {
            Err(NodeDelayError::Failed(format!(
                "node delay {node}: zero delay"
            )))
        } else {
            Ok(delay)
        }
    }

    /// 主目标固定；仅节点超时复核 HTTPS。每次新请求前及发布结果前均检查取消。
    pub(crate) fn measure_node_delay_with_review(
        &self,
        node: &str,
        current: &impl Fn() -> bool,
        deadline: std::time::Instant,
        url_scoped_history: bool,
    ) -> Result<DelaySample, NodeDelayError> {
        let check = || {
            if !current() {
                Err(NodeDelayError::Cancelled("测速已取消或配置已变化".into()))
            } else if std::time::Instant::now() >= deadline {
                Err(NodeDelayError::Skipped("批次总预算已耗尽".into()))
            } else {
                Ok(())
            }
        };
        let probe = |url| {
            check()?;
            let timeout = deadline
                .saturating_duration_since(std::time::Instant::now())
                .min(NODE_DELAY_REQUEST_BUDGET);
            if timeout.is_zero() {
                return Err(NodeDelayError::Skipped("批次总预算已耗尽".into()));
            }
            let result = self.measure_via_with_timeout(node, url, timeout);
            check()?;
            result
        };
        // sing-box 的测速会覆盖同一份选路历史，且忽略 HTTP URL。
        // 未能按 URL 分离历史的控制器只测固定 HTTPS 主目标，不注入异站延迟。
        let primary = if url_scoped_history {
            BENCHMARK_URL
        } else {
            BENCHMARK_URL_HTTPS
        };
        let (delay_ms, reviewed, target, sample_count) = match probe(primary) {
            Ok(ms) => (ms, false, primary, 1),
            Err(NodeDelayError::Timeout(_)) if url_scoped_history => {
                (probe(BENCHMARK_URL_REVIEW)?, true, BENCHMARK_URL_REVIEW, 2)
            }
            Err(other) => return Err(other),
        };
        Ok(DelaySample {
            delay_ms,
            reviewed,
            target: target.into(),
            sample_count,
            tested_at_ms: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_millis() as u64,
        })
    }
}

/// `/dns/query` 的查询串：域名已由调用方校验，仍做一次百分号编码防御。
pub(crate) fn dns_query_path(name: &str, record_type: &str) -> String {
    let encoded: String = url::form_urlencoded::byte_serialize(name.as_bytes()).collect();
    format!("/dns/query?name={encoded}&type={record_type}")
}

/// 拼接并编码路径段（组名常含中文/空格/emoji）。
fn build_path(segments: &[&str]) -> String {
    let mut out = String::new();
    for seg in segments {
        out.push('/');
        for b in seg.trim_start_matches('/').bytes() {
            let c = b as char;
            if c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.' | '~') {
                out.push(c);
            } else {
                out.push_str(&format!("%{b:02X}"));
            }
        }
    }
    out
}

#[cfg(test)]
pub(crate) mod tests {
    use super::*;

    #[test]
    fn node_delay_distinguishes_controller_timeout_from_other_failures() {
        let node = "Node 504 timeout";
        let path = format!(
            "{}?url={BENCHMARK_URL}&timeout=5000",
            build_path(&["/proxies", node, "delay"])
        );
        let (controller, server) = scripted_controller(vec![
            ("GET", path.clone(), 504, "{}".into()),
            ("GET", path.clone(), 503, "{}".into()),
            ("GET", path, 200, "{\"delay\":42}".into()),
        ]);
        assert!(matches!(
            controller.measure_node_delay(node),
            Err(NodeDelayError::Timeout(_))
        ));
        assert!(matches!(
            controller.measure_node_delay(node),
            Err(NodeDelayError::Failed(_))
        ));
        assert_eq!(controller.test_node_delay(node).unwrap(), 42);
        server.join().unwrap();
        // 控制器不可达 = Controller（不是节点故障，#491）。
        assert!(matches!(
            controller.measure_node_delay(node),
            Err(NodeDelayError::Controller(_))
        ));
    }

    /// #491：主目标超时 → 不同运营方的复核目标再测一次；复核成功单独
    /// 标记（不与主目标混排），两目标超时分别归为目标探测超时。控制层错误不复核。
    #[test]
    fn timeout_review_uses_independent_target_and_marks_the_sample() {
        let node = "Node 504";
        let primary = format!(
            "{}?url={BENCHMARK_URL}&timeout=5000",
            build_path(&["/proxies", node, "delay"])
        );
        let review = format!(
            "{}?url={BENCHMARK_URL_REVIEW}&timeout=5000",
            build_path(&["/proxies", node, "delay"])
        );
        let (controller, server) = scripted_controller(vec![
            ("GET", primary.clone(), 504, "{}".into()),
            ("GET", review.clone(), 200, "{\"delay\":88}".into()),
        ]);
        let sample = controller
            .measure_node_delay_with_review(
                node,
                &|| true,
                std::time::Instant::now() + Duration::from_secs(20),
                true,
            )
            .unwrap();
        assert_eq!(sample.delay_ms, 88);
        assert!(sample.reviewed);
        server.join().unwrap();
    }

    #[test]
    fn review_failure_is_a_node_timeout_and_controller_errors_skip_review() {
        let node = "Node both";
        let primary = format!(
            "{}?url={BENCHMARK_URL}&timeout=5000",
            build_path(&["/proxies", node, "delay"])
        );
        let review = format!(
            "{}?url={BENCHMARK_URL_REVIEW}&timeout=5000",
            build_path(&["/proxies", node, "delay"])
        );
        // 两轮都超时 = Timeout（不等同于控制器错误），且请求顺序 = 主 → 复核。
        let (controller, server) = scripted_controller(vec![
            ("GET", primary.clone(), 504, "{}".into()),
            ("GET", review.clone(), 504, "{}".into()),
        ]);
        assert!(matches!(
            controller.measure_node_delay_with_review(
                node,
                &|| true,
                std::time::Instant::now() + Duration::from_secs(20),
                true,
            ),
            Err(NodeDelayError::Timeout(_))
        ));
        server.join().unwrap();

        // 控制器传输失败（服务器已关）：直接 Controller，不发复核请求。
        let (controller, dead_server) = scripted_controller(vec![]);
        dead_server.join().unwrap();
        assert!(matches!(
            controller.measure_node_delay_with_review(
                node,
                &|| true,
                std::time::Instant::now() + Duration::from_secs(20),
                true,
            ),
            Err(NodeDelayError::Controller(_))
        ));
        let _ = controller;
    }

    #[test]
    fn healthy_primary_has_one_sample_and_cancelled_or_expired_tests_make_no_requests() {
        let node = "one";
        let primary = format!(
            "{}?url={BENCHMARK_URL}&timeout=5000",
            build_path(&["/proxies", node, "delay"])
        );
        let (controller, server) =
            scripted_controller(vec![("GET", primary, 200, "{\"delay\":33}".into())]);
        let sample = controller
            .measure_node_delay_with_review(
                node,
                &|| true,
                std::time::Instant::now() + Duration::from_secs(5),
                true,
            )
            .unwrap();
        assert_eq!(sample.target, BENCHMARK_URL);
        assert_eq!(sample.sample_count, 1);
        assert!(!sample.reviewed);
        assert!(sample.tested_at_ms > 0);
        server.join().unwrap();
        assert!(matches!(
            controller.measure_node_delay_with_review(
                node,
                &|| false,
                std::time::Instant::now() + Duration::from_secs(5),
                true
            ),
            Err(NodeDelayError::Cancelled(_))
        ));
        assert!(matches!(
            controller.measure_node_delay_with_review(
                node,
                &|| true,
                std::time::Instant::now(),
                true
            ),
            Err(NodeDelayError::Skipped(_))
        ));
    }

    #[test]
    fn cancellation_during_primary_prevents_late_success_and_review_requests() {
        for status in [200, 504] {
            let node = "cancel";
            let primary = format!(
                "{}?url={BENCHMARK_URL}&timeout=5000",
                build_path(&["/proxies", node, "delay"])
            );
            let (controller, server) =
                scripted_controller(vec![("GET", primary, status, "{\"delay\":30}".into())]);
            let checks = std::cell::Cell::new(0);
            let current = || {
                let old = checks.get();
                checks.set(old + 1);
                old == 0
            };
            assert!(matches!(
                controller.measure_node_delay_with_review(
                    node,
                    &current,
                    std::time::Instant::now() + Duration::from_secs(5),
                    true
                ),
                Err(NodeDelayError::Cancelled(_))
            ));
            server.join().unwrap();
        }
    }

    #[test]
    fn controllers_with_shared_selection_history_do_not_get_an_alternate_target() {
        let node = "shared-history";
        let primary = format!(
            "{}?url={BENCHMARK_URL_HTTPS}&timeout=5000",
            build_path(&["/proxies", node, "delay"])
        );
        let (controller, server) = scripted_controller(vec![("GET", primary, 504, "{}".into())]);
        assert!(matches!(
            controller.measure_node_delay_with_review(
                node,
                &|| true,
                std::time::Instant::now() + Duration::from_secs(5),
                false
            ),
            Err(NodeDelayError::Timeout(_))
        ));
        server.join().unwrap();
    }

    #[test]
    fn malformed_controller_reply_is_not_a_node_failure() {
        let node = "bad-json";
        let primary = format!(
            "{}?url={BENCHMARK_URL}&timeout=5000",
            build_path(&["/proxies", node, "delay"])
        );
        let (controller, server) =
            scripted_controller(vec![("GET", primary, 200, "invalid JSON".into())]);
        assert!(matches!(
            controller.measure_node_delay_with_review(
                node,
                &|| true,
                std::time::Instant::now() + Duration::from_secs(5),
                true
            ),
            Err(NodeDelayError::Controller(_))
        ));
        server.join().unwrap();
    }

    #[test]
    fn controller_statuses_and_removed_nodes_are_not_node_failures() {
        for status in [302, 400, 401, 403, 404, 500] {
            let node = "status";
            let path = format!(
                "{}?url={BENCHMARK_URL}&timeout=5000",
                build_path(&["/proxies", node, "delay"])
            );
            let (controller, server) =
                scripted_controller(vec![("GET", path, status, "{}".into())]);
            let result = controller.measure_node_delay_with_review(
                node,
                &|| true,
                std::time::Instant::now() + Duration::from_secs(5),
                true,
            );
            if status == 404 {
                assert!(matches!(result, Err(NodeDelayError::Skipped(_))));
            } else {
                assert!(matches!(result, Err(NodeDelayError::Controller(_))));
            }
            server.join().unwrap();
        }
    }

    #[test]
    fn groups_do_not_reuse_review_latency_as_a_primary_measurement() {
        let raw = serde_json::json!({"proxies": {
            "Group": {"type": "Selector", "all": ["A", "B", "C", "Legacy"]},
            "A": {"type":"Direct", "history":[{"delay":88}], "extra": {
                BENCHMARK_URL: {"history":[{"delay":31}]}, BENCHMARK_URL_REVIEW: {"history":[{"delay":88}]}}},
            "B": {"type":"Direct", "history":[{"delay":88}], "extra": {
                BENCHMARK_URL: {"history":[{"delay":0}]}, BENCHMARK_URL_REVIEW: {"history":[{"delay":88}]}}},
            "C": {"type":"Direct", "history":[{"delay":88}], "extra": {BENCHMARK_URL_REVIEW: {"history":[{"delay":88}]}}},
            "Legacy": {"type":"Direct", "history":[{"delay":42}]}
        }});
        let (controller, server) =
            scripted_controller(vec![("GET", "/proxies".into(), 200, raw.to_string())]);
        let groups = controller.groups().unwrap();
        let values: Vec<_> = groups[0].nodes.iter().map(|node| node.delay_ms).collect();
        assert_eq!(values, vec![Some(31), None, None, Some(42)]);
        server.join().unwrap();
    }

    /// A scripted controller checks the actual HTTP contract and request order.
    fn scripted_controller(
        steps: Vec<(&str, String, u16, String)>,
    ) -> (Controller, std::thread::JoinHandle<()>) {
        use std::io::{Read, Write};
        use std::net::TcpListener;
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let port = listener.local_addr().unwrap().port();
        listener.set_nonblocking(true).unwrap();
        let steps: Vec<_> = steps
            .into_iter()
            .map(|(m, p, s, b)| (m.to_owned(), p, s, b))
            .collect();
        let server = std::thread::spawn(move || {
            for (method, path, status, body) in steps {
                let deadline = std::time::Instant::now() + Duration::from_secs(8);
                let mut stream = loop {
                    match listener.accept() {
                        Ok((stream, _)) => break stream,
                        Err(e)
                            if e.kind() == std::io::ErrorKind::WouldBlock
                                && std::time::Instant::now() < deadline =>
                        {
                            std::thread::sleep(Duration::from_millis(5))
                        }
                        Err(e) => panic!("missing {method} {path}: {e}"),
                    }
                };
                // macOS/BSD 的 accept 会让连接继承 listener 的 O_NONBLOCK，
                // 不清掉的话数据未到达时 read 立即返回 WouldBlock（Linux 会清）。
                stream.set_nonblocking(false).unwrap();
                stream
                    .set_read_timeout(Some(Duration::from_secs(5)))
                    .unwrap();
                let mut request = Vec::new();
                let mut buf = [0; 1024];
                loop {
                    let n = stream.read(&mut buf).unwrap();
                    assert!(n > 0);
                    request.extend_from_slice(&buf[..n]);
                    if let Some(end) = request.windows(4).position(|w| w == b"\r\n\r\n") {
                        let headers = String::from_utf8_lossy(&request[..end]).to_ascii_lowercase();
                        let length = headers
                            .lines()
                            .find_map(|line| line.strip_prefix("content-length: "))
                            .and_then(|s| s.parse::<usize>().ok())
                            .unwrap_or(0);
                        if request.len() >= end + 4 + length {
                            break;
                        }
                    }
                }
                let request = String::from_utf8(request).unwrap();
                assert!(
                    request.starts_with(&format!("{method} {path} HTTP/1.1")),
                    "{request}"
                );
                assert!(request
                    .to_ascii_lowercase()
                    .contains("authorization: bearer test-secret"));
                if method == "PUT" {
                    assert!(serde_json::from_str::<serde_json::Value>(
                        request.split("\r\n\r\n").nth(1).unwrap()
                    )
                    .unwrap()["name"]
                        .is_string());
                }
                write!(stream, "HTTP/1.1 {status} Test\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len()).unwrap();
            }
        });
        (
            Controller {
                port,
                secret: "test-secret".into(),
            },
            server,
        )
    }

    #[test]
    fn selecting_automatic_child_unpins_before_selecting_parent() {
        let parent = build_path(&["/proxies", "节点选择"]);
        let child = build_path(&["/proxies", "♻️ 自动选择"]);
        let source = r#"{"type":"Selector","all":["♻️ 自动选择"]}"#.to_string();
        let target = r#"{"type":"URLTest","fixed":"JP"}"#.to_string();
        let (c, server) = scripted_controller(vec![
            ("GET", parent.clone(), 200, source),
            ("GET", child.clone(), 200, target.clone()),
            ("GET", child.clone(), 200, target),
            ("DELETE", child, 204, "".into()),
            ("PUT", parent, 204, "".into()),
        ]);
        c.select_proxy("节点选择", "♻️ 自动选择").unwrap();
        server.join().unwrap();
    }

    #[test]
    fn selecting_automatic_child_propagates_reset_failure() {
        let (c, server) = scripted_controller(vec![
            (
                "GET",
                "/proxies/main".into(),
                200,
                r#"{"type":"Selector","all":["auto"]}"#.into(),
            ),
            (
                "GET",
                "/proxies/auto".into(),
                200,
                r#"{"type":"URLTest","fixed":"JP"}"#.into(),
            ),
            (
                "GET",
                "/proxies/auto".into(),
                200,
                r#"{"type":"URLTest","fixed":"JP"}"#.into(),
            ),
            ("DELETE", "/proxies/auto".into(), 500, "{}".into()),
        ]);
        assert!(c
            .select_proxy("main", "auto")
            .unwrap_err()
            .contains("restore automatic selection"));
        server.join().unwrap();
    }

    #[test]
    fn automatic_child_without_fixed_support_is_not_deleted() {
        // sing-box Clash API does not expose mihomo's fixed contract.
        let (c, server) = scripted_controller(vec![
            (
                "GET",
                "/proxies/main".into(),
                200,
                r#"{"type":"Selector","all":["auto"]}"#.into(),
            ),
            (
                "GET",
                "/proxies/auto".into(),
                200,
                r#"{"type":"URLTest"}"#.into(),
            ),
            ("PUT", "/proxies/main".into(), 204, "".into()),
        ]);
        c.select_proxy("main", "auto").unwrap();
        server.join().unwrap();
    }

    #[test]
    fn pinning_inside_urltest_does_not_restore_automatic() {
        let (c, server) = scripted_controller(vec![
            (
                "GET",
                "/proxies/auto".into(),
                200,
                r#"{"type":"URLTest","all":["JP"],"fixed":""}"#.into(),
            ),
            ("PUT", "/proxies/auto".into(), 204, "".into()),
        ]);
        c.select_proxy("auto", "JP").unwrap();
        server.join().unwrap();
    }

    #[test]
    fn reset_is_idempotent_and_rejects_unsupported_groups() {
        for (raw, ok) in [
            (r#"{"type":"URLTest","fixed":""}"#, true),
            (r#"{"type":"URLTest"}"#, false),
            (r#"{"type":"Selector","fixed":"JP"}"#, false),
        ] {
            let (c, server) =
                scripted_controller(vec![("GET", "/proxies/auto".into(), 200, raw.into())]);
            assert_eq!(c.reset_proxy_selection("auto").is_ok(), ok);
            server.join().unwrap();
        }
    }

    #[test]
    fn snapshot_preserves_fixed_separately_from_current_outbound() {
        let (c, server) = scripted_controller(vec![(
            "GET",
            "/proxies".into(),
            200,
            r#"{"proxies":{
            "auto":{"type":"URLTest","all":["JP","SG"],"now":"SG","fixed":"JP"},
            "free":{"type":"URLTest","all":["JP"],"now":"JP","fixed":""},
            "JP":{"type":"Direct"},"SG":{"type":"Direct"}}}"#
                .into(),
        )]);
        let groups = c.groups().unwrap();
        let auto = groups.iter().find(|g| g.name == "auto").unwrap();
        assert_eq!(auto.now.as_deref(), Some("SG"));
        assert_eq!(auto.fixed.as_deref(), Some("JP"));
        assert!(groups
            .iter()
            .find(|g| g.name == "free")
            .unwrap()
            .fixed
            .is_none());
        server.join().unwrap();
    }

    #[test]
    fn config_outbound_requires_two_definite_failures_and_resolves_again() {
        let targets = ["https://one.invalid/a", "https://two.invalid/b"];
        for (second_status, expected) in [(200, Some(true)), (503, Some(false)), (404, None)] {
            let mut requests = Vec::new();
            for (node, target, status) in
                [("JP", targets[0], 504), ("SG", targets[1], second_status)]
            {
                requests.extend([
                    ("GET", "/configs".into(), 200, r#"{"mode":"rule"}"#.into()),
                    ("GET", "/proxies".into(), 200, format!(r#"{{"proxies":{{"AUTO":{{"type":"URLTest","all":["JP","SG"],"now":"{node}"}},"{node}":{{"type":"Shadowsocks"}}}}}}"#)),
                    ("GET", "/rules".into(), 200, r#"{"rules":[{"type":"Match","proxy":"AUTO"}]}"#.into()),
                    ("GET", format!("/proxies/{node}/delay?url={}&timeout=3000", target.replace(':', "%3A").replace('/', "%2F")), status, r#"{"delay":37}"#.into()),
                ]);
            }
            let (controller, server) = scripted_controller(requests);
            assert_eq!(controller.probe_config_outbound(targets), expected);
            server.join().unwrap();
        }
    }

    #[test]
    fn real_core_rolls_back_successful_reload_when_selected_exit_is_unreachable() {
        use crate::engine::config_transition::{execute, Transaction};
        use crate::engine::manager::{tests::REAL_CORE_LOCK, CoreManager, CoreOptions, CoreStatus};
        use std::io::{BufRead, BufReader, Write};
        use std::net::TcpListener;
        use std::time::Instant;

        let Ok(bin) = std::env::var("CROSSBOW_CORE_BIN") else {
            eprintln!("skip: CROSSBOW_CORE_BIN not set");
            return;
        };
        let _serial = REAL_CORE_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let dir = tempfile::tempdir().unwrap();
        let manager = CoreManager::new(bin.into(), dir.path().to_path_buf());
        manager.set_options(CoreOptions {
            ensure_geo_files: false,
            ..CoreOptions::default()
        });
        let upstream = TcpListener::bind("127.0.0.1:0").unwrap();
        upstream.set_nonblocking(true).unwrap();
        let upstream_port = upstream.local_addr().unwrap().port();
        let unreachable = TcpListener::bind("127.0.0.1:0").unwrap();
        let unreachable_port = unreachable.local_addr().unwrap().port();
        let origin = std::thread::spawn(move || {
            let deadline = Instant::now() + Duration::from_secs(20);
            for _ in 0..2 {
                let stream = loop {
                    match upstream.accept() {
                        Ok((stream, _)) => break stream,
                        Err(error)
                            if error.kind() == std::io::ErrorKind::WouldBlock
                                && Instant::now() < deadline =>
                        {
                            std::thread::sleep(Duration::from_millis(10));
                        }
                        Err(error) => panic!("test upstream received no connection: {error}"),
                    }
                };
                stream.set_nonblocking(false).unwrap();
                stream
                    .set_read_timeout(Some(Duration::from_secs(3)))
                    .unwrap();
                let mut stream = BufReader::new(stream);
                for (method, response) in [
                    (
                        "CONNECT ",
                        b"HTTP/1.1 200 Connection established\r\n\r\n".as_slice(),
                    ),
                    (
                        "HEAD ",
                        b"HTTP/1.1 204 No Content\r\nConnection: close\r\n\r\n".as_slice(),
                    ),
                ] {
                    let mut line = String::new();
                    stream.read_line(&mut line).unwrap();
                    assert!(line.starts_with(method), "{line}");
                    loop {
                        line.clear();
                        assert_ne!(stream.read_line(&mut line).unwrap(), 0);
                        if line == "\r\n" {
                            break;
                        }
                    }
                    std::thread::sleep(Duration::from_millis(10));
                    stream.get_mut().write_all(response).unwrap();
                }
            }
        });
        let config = format!("proxies: [{{name: test, type: http, server: 127.0.0.1, port: {upstream_port}}}]\nproxy-groups: [{{name: OUT, type: select, proxies: [test]}}]\nrules: ['DOMAIN-SUFFIX,invalid,DIRECT', 'MATCH,OUT']\n");
        manager
            .start(
                &config,
                &crossbow_core::RuntimeConfig {
                    mixed_port: crate::engine::manager::tests::tests_free_port(),
                    ..crossbow_core::RuntimeConfig::default()
                },
            )
            .unwrap();
        let deadline = Instant::now() + Duration::from_secs(10);
        while manager.status() != CoreStatus::Running {
            assert!(Instant::now() < deadline, "{:?}", manager.status());
            std::thread::sleep(Duration::from_millis(30));
        }
        struct Reload<'a> {
            manager: &'a CoreManager,
            controller: Controller,
            previous: String,
            candidate: String,
            persisted: bool,
        }
        impl Reload<'_> {
            fn reload(&self, config: &str) -> Result<(), String> {
                self.manager.write_config_file(config)?;
                self.controller.reload_config(&self.manager.config_path())?;
                self.manager.replace_cached_config(config.to_owned());
                Ok(())
            }
        }
        impl Transaction for Reload<'_> {
            fn probe_outbound(&mut self) -> Option<bool> {
                self.controller
                    .probe_config_outbound(["http://one.invalid/", "http://two.invalid/"])
            }
            fn apply(&mut self) -> Result<(), String> {
                self.reload(&self.candidate)
                    .expect("mihomo accepts the candidate");
                assert!(self.controller.version().is_ok());
                Ok(())
            }
            fn persist(&mut self) -> Result<(), String> {
                self.persisted = true;
                Ok(())
            }
            fn rollback(&mut self) -> Result<(), String> {
                self.reload(&self.previous)
            }
        }

        let previous = manager.current_config().unwrap();
        let pid = manager.pid();
        let candidate = previous.replace(
            &format!("port: {upstream_port}"),
            &format!("port: {unreachable_port}"),
        );
        assert_ne!(candidate, previous);
        let (port, secret) = manager.controller().unwrap();
        let mut transaction = Reload {
            manager: &manager,
            controller: Controller { port, secret },
            previous,
            candidate,
            persisted: false,
        };
        let error = execute(&mut transaction).unwrap_err();
        assert!(error.contains("已恢复之前的状态") && error.contains("默认代理出口连接失败"));
        assert!(!transaction.persisted);
        assert_eq!(
            manager.current_config().as_ref(),
            Some(&transaction.previous)
        );
        assert_eq!(manager.pid(), pid);
        origin.join().unwrap();
        assert!(manager.stop());
    }

    #[test]
    fn real_core_urltest_pin_and_restore() {
        let _serial = crate::engine::manager::tests::REAL_CORE_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let Ok(bin) = std::env::var("CROSSBOW_CORE_BIN") else {
            return;
        };
        let dir = tempfile::tempdir().unwrap();
        let mgr = crate::engine::manager::CoreManager::new(bin.into(), dir.path().to_path_buf());
        mgr.set_options(crate::engine::manager::CoreOptions {
            ensure_geo_files: false,
            ..Default::default()
        });
        let config = "proxies:\n  - {name: OUT-DIRECT, type: direct}\nproxy-groups:\n  - {name: main, type: select, proxies: [auto, OUT-DIRECT]}\n  - {name: auto, type: url-test, proxies: [OUT-DIRECT], url: 'http://127.0.0.1:9', interval: 0}\nrules:\n  - MATCH,DIRECT\n";
        mgr.start(
            config,
            &crossbow_core::RuntimeConfig {
                mixed_port: crate::engine::manager::tests::tests_free_port(),
                ..Default::default()
            },
        )
        .unwrap();
        for _ in 0..100 {
            if mgr.status() == crate::engine::manager::CoreStatus::Running {
                break;
            }
            std::thread::sleep(Duration::from_millis(100));
        }
        let (port, secret) = mgr.controller().unwrap();
        let c = Controller { port, secret };
        c.select_proxy("auto", "OUT-DIRECT").unwrap();
        assert_eq!(
            c.groups()
                .unwrap()
                .iter()
                .find(|g| g.name == "auto")
                .unwrap()
                .fixed
                .as_deref(),
            Some("OUT-DIRECT")
        );
        c.select_proxy("main", "auto").unwrap();
        assert!(c
            .groups()
            .unwrap()
            .iter()
            .find(|g| g.name == "auto")
            .unwrap()
            .fixed
            .is_none());
        c.select_proxy("auto", "OUT-DIRECT").unwrap();
        c.reset_proxy_selection("auto").unwrap();
        c.reset_proxy_selection("auto").unwrap();
        assert!(c
            .groups()
            .unwrap()
            .iter()
            .find(|g| g.name == "auto")
            .unwrap()
            .fixed
            .is_none());
        mgr.stop();
        // DELETE must clear persistent selection too; a restart must not pin it again.
        mgr.start(
            config,
            &crossbow_core::RuntimeConfig {
                mixed_port: crate::engine::manager::tests::tests_free_port(),
                ..Default::default()
            },
        )
        .unwrap();
        for _ in 0..100 {
            if mgr.status() == crate::engine::manager::CoreStatus::Running {
                break;
            }
            std::thread::sleep(Duration::from_millis(100));
        }
        let (port, secret) = mgr.controller().unwrap();
        let restarted = Controller { port, secret };
        assert!(restarted
            .groups()
            .unwrap()
            .iter()
            .find(|g| g.name == "auto")
            .unwrap()
            .fixed
            .is_none());
        mgr.stop();
    }

    #[test]
    fn tun_device_requires_enabled_live_interface() {
        use std::io::{Read, Write};
        use std::net::TcpListener;

        for (body, expected, enabled) in [
            (
                r#"{"tun":{"enable":true,"device":"utun4"}}"#,
                (!cfg!(target_os = "windows")).then_some("utun4"),
                Some(true),
            ),
            (
                r#"{"tun":{"enable":false,"device":"utun4"}}"#,
                None,
                Some(false),
            ),
            (
                r#"{"tun":{"enable":true,"device":"utun"}}"#,
                None,
                Some(true),
            ),
            (
                r#"{"tun":{"enable":true,"device":"en0"}}"#,
                None,
                Some(true),
            ),
            (
                r#"{"tun":{"enable":true,"device":"Crossbow"}}"#,
                cfg!(target_os = "windows").then_some("Crossbow"),
                Some(true),
            ),
            (r#"{"tun":{"enable":true}}"#, None, Some(true)),
            (r#"{}"#, None, None),
        ] {
            let listener = TcpListener::bind("127.0.0.1:0").unwrap();
            let port = listener.local_addr().unwrap().port();
            let server = std::thread::spawn(move || {
                for _ in 0..2 {
                    let (mut stream, _) = listener.accept().unwrap();
                    // macOS/BSD 的 accept 会让连接继承 listener 的 O_NONBLOCK，
                    // 不清掉的话数据未到达时 read 立即返回 WouldBlock（Linux 会清）。
                    stream.set_nonblocking(false).unwrap();
                    stream
                        .set_read_timeout(Some(Duration::from_secs(5)))
                        .unwrap();
                    let mut request = Vec::new();
                    let mut buf = [0; 512];
                    while !request.windows(4).any(|w| w == b"\r\n\r\n") {
                        let n = stream.read(&mut buf).unwrap();
                        assert!(n > 0);
                        request.extend_from_slice(&buf[..n]);
                    }
                    let request = String::from_utf8(request).unwrap();
                    assert!(request.starts_with("GET /configs HTTP/1.1"));
                    assert!(request
                        .to_ascii_lowercase()
                        .contains("authorization: bearer test-secret"));
                    write!(stream, "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len()).unwrap();
                }
            });
            let client = Controller {
                port,
                secret: "test-secret".into(),
            };
            assert_eq!(client.active_tun_device().unwrap().as_deref(), expected);
            assert_eq!(client.tun_enabled().unwrap(), enabled);
            server.join().unwrap();
        }
    }

    #[test]
    fn path_encoding_handles_cjk_and_spaces() {
        assert_eq!(
            build_path(&["/proxies", "香港 自动"]),
            "/proxies/%E9%A6%99%E6%B8%AF%20%E8%87%AA%E5%8A%A8"
        );
        assert_eq!(build_path(&["/proxies", "HK-01"]), "/proxies/HK-01");
    }

    #[test]
    fn groups_filters_and_maps_delay() {
        // groups() 需要 HTTP；这里只测路径构建与解析辅助——延迟映射逻辑内联验证
        let raw = serde_json::json!({
            "proxies": {
                "节点选择": { "type": "Selector", "now": "HK-01", "all": ["HK-01", "US-01"] },
                "HK-01": { "type": "Shadowsocks", "alive": true,
                           "history": [{"time": "t1", "delay": 128}] },
                "US-01": { "type": "Trojan", "alive": false, "history": [] },
                "DIRECT": { "type": "Direct" }
            }
        });
        let all = raw.get("proxies").unwrap().as_object().unwrap();
        let names: Vec<_> = all.keys().cloned().collect();
        assert!(names.contains(&"节点选择".to_string()));
        let delay = all["HK-01"]["history"].as_array().unwrap().last().unwrap()["delay"].as_u64();
        assert_eq!(delay, Some(128));
    }

    /// 真实内核：组快照 → 选择 → 单节点测速 全链路。
    #[test]
    fn real_core_groups_select_and_delay() {
        let _serial = crate::engine::manager::tests::REAL_CORE_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let Ok(bin) = std::env::var("CROSSBOW_CORE_BIN") else {
            eprintln!("skip: CROSSBOW_CORE_BIN not set");
            return;
        };
        let dir = tempfile::tempdir().unwrap();
        let mgr = crate::engine::manager::CoreManager::new(
            std::path::PathBuf::from(bin),
            dir.path().to_path_buf(),
        );
        mgr.set_options(crate::engine::manager::CoreOptions {
            ensure_geo_files: false,
            ..crate::engine::manager::CoreOptions::default()
        });
        let config = "proxies:\n  - name: OUT-DIRECT\n    type: direct\nproxy-groups:\n  - name: \u{8282}\u{70b9}\u{9009}\u{62e9}\n    type: select\n    proxies:\n      - OUT-DIRECT\nrules:\n  - MATCH,DIRECT\n";
        mgr.start(
            config,
            &crossbow_core::RuntimeConfig {
                mixed_port: crate::engine::manager::tests::tests_free_port(),
                ..crossbow_core::RuntimeConfig::default()
            },
        )
        .unwrap();
        let mut running = false;
        for _ in 0..100 {
            if mgr.status() == crate::engine::manager::CoreStatus::Running {
                running = true;
                break;
            }
            std::thread::sleep(std::time::Duration::from_millis(100));
        }
        assert!(running);

        let (port, secret) = mgr.controller().unwrap();
        let c = Controller { port, secret };

        let groups = c.groups().unwrap();
        let sel = groups
            .iter()
            .find(|g| g.name == "\u{8282}\u{70b9}\u{9009}\u{62e9}")
            .expect("selector group present");
        assert_eq!(sel.nodes.len(), 1);
        assert_eq!(sel.nodes[0].name, "OUT-DIRECT");

        c.select_proxy("\u{8282}\u{70b9}\u{9009}\u{62e9}", "OUT-DIRECT")
            .unwrap();

        let delay = c.test_node_delay("OUT-DIRECT").unwrap();
        assert!(delay > 0, "direct adapter should answer the probe");

        mgr.stop();
    }

    #[test]
    fn dns_query_rejects_oversized_controller_replies() {
        use std::io::{Read, Write};
        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let port = listener.local_addr().unwrap().port();
        let server = std::thread::spawn(move || {
            let (mut stream, _) = listener.accept().unwrap();
            let mut buf = [0; 2048];
            let _ = stream.read(&mut buf);
            let body = vec![b' '; 256 * 1024 + 1];
            let _ = write!(
                stream,
                "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n",
                body.len()
            );
            let _ = stream.write_all(&body);
        });
        let error = Controller {
            port,
            secret: "synthetic".into(),
        }
        .dns_query("example.test", "A")
        .unwrap_err();
        assert!(error.contains("too large"));
        server.join().unwrap();
    }

    /// #603：真实内核的 `/dns/query`。需要联网解析上游，默认跳过；
    /// `CROSSBOW_CORE_BIN=<mihomo> cargo test -- --ignored real_core_dns_query`。
    #[test]
    #[ignore = "requires CROSSBOW_CORE_BIN (mihomo) and network access for the upstream resolver"]
    fn real_core_dns_query_reports_answers_and_nxdomain() {
        let _serial = crate::engine::manager::tests::REAL_CORE_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let Ok(bin) = std::env::var("CROSSBOW_CORE_BIN") else {
            return;
        };
        let dir = tempfile::tempdir().unwrap();
        let mgr = crate::engine::manager::CoreManager::new(bin.into(), dir.path().to_path_buf());
        mgr.set_options(crate::engine::manager::CoreOptions {
            ensure_geo_files: false,
            ..Default::default()
        });
        let config = "dns:\n  enable: true\n  ipv6: true\n  nameserver:\n    - 1.1.1.1\nrules:\n  - MATCH,DIRECT\n";
        mgr.start(
            config,
            &crossbow_core::RuntimeConfig {
                mixed_port: crate::engine::manager::tests::tests_free_port(),
                ..Default::default()
            },
        )
        .unwrap();
        for _ in 0..100 {
            if mgr.status() == crate::engine::manager::CoreStatus::Running {
                break;
            }
            std::thread::sleep(Duration::from_millis(100));
        }
        let (port, secret) = mgr.controller().unwrap();
        let c = Controller { port, secret };
        let reply = c.dns_query("example.com", "A").unwrap();
        assert_eq!(reply["Status"].as_i64(), Some(0));
        assert!(!reply["Answer"].as_array().unwrap().is_empty());
        let missing = c
            .dns_query("crossbow-603-nonexistent.invalid", "A")
            .unwrap();
        assert_eq!(missing["Status"].as_i64(), Some(3));
        mgr.stop();
    }
}
