import {useCallback,useEffect,useRef,useState} from "react";
import Modal from "@/components/Modal";
import Select from "@/components/Select";
import {Input} from "@/components/Controls";
import {Button} from "@/components/Button";
import {ipc,type CustomGroup,type CustomGroupStatus,type GroupResolution} from "@/services/ipc";
import {notify} from "@/notifications/service";
import {useT} from "@/i18n/i18n";
import "../ProcessRules/ProcessRules.css";
import "./CustomGroups.css";
export default function CustomGroups({onClose,onChanged}:{onClose:()=>void;onChanged:()=>void}) {
 const t=useT(),alive=useRef(false),seq=useRef(0),pending=useRef(false),baseline=useRef<CustomGroup[]>([]);
 const [status,setStatus]=useState<CustomGroupStatus|null>(null),[draft,setDraft]=useState<CustomGroup|null>(null),[preview,setPreview]=useState<GroupResolution|null>(null),[checking,setChecking]=useState(false),[busy,setBusy]=useState(false),[failed,setFailed]=useState(false);
 const load=useCallback(async()=>{const id=++seq.current;try{const result=await ipc.customGroups();if(alive.current&&id===seq.current){setStatus(result);setFailed(false);void notify.resolve("custom-groups-read");}}catch(e){if(alive.current&&id===seq.current){setFailed(true);notify.error(e,"custom-groups-read");}}},[]);
 useEffect(()=>{alive.current=true;void load();const off=[ipc.onProfileSwitched(()=>void load()),ipc.onProfileUpdated(()=>void load()),ipc.onEngineChanged(()=>void load())];return()=>{alive.current=false;seq.current++;off.forEach(p=>void p.then(f=>f(),e=>notify.error(e,"custom-groups-listener")));};},[load]);
 useEffect(()=>{let current=true;setPreview(null);if(!draft||!status)return;setChecking(true);const timer=setTimeout(()=>void ipc.previewCustomGroup(draft,status.context).then(p=>{if(current){setPreview(p);setChecking(false);void notify.resolve("custom-group-preview");}},e=>{if(current){notify.error(e,"custom-group-preview");setPreview({members:[],missing:[],error:String(e)});setChecking(false);}}),250);return()=>{current=false;clearTimeout(timer);};},[draft,status?.context]);
 const open=(group:CustomGroup)=>{baseline.current=status?.groups??[];setDraft({...group,members:[...group.members]});};
 // 列表里只展示前几个成员，其余用 +N 收敛；完整名单放在 title 里，避免长列表挤走编辑入口。
 const memberText=(resolved?:GroupResolution)=>{
  if(!resolved)return "—";
  if(resolved.error)return resolved.error;
  const shown=resolved.members.slice(0,6);
  return shown.join(" · ")+(resolved.members.length>shown.length?` +${resolved.members.length-shown.length}`:"");
 };
 const save=async(groups:CustomGroup[],expected=baseline.current)=>{if(!status||pending.current||failed)return;pending.current=true;setBusy(true);try{const result=await notify.run(`custom-group-${crypto.randomUUID()}`,t("cg.title"),()=>ipc.setCustomGroups(expected,groups,status.context));if(alive.current&&result.ok){setDraft(null);await load();onChanged();}}finally{pending.current=false;if(alive.current)setBusy(false);}};
 return <Modal footer={draft ? <div className="cb-process-form-actions">{status?.groups.some(g=>g.id===draft.id)&&<Button tone="danger" disabled={busy} onClick={()=>void save(baseline.current.filter(g=>g.id!==draft.id))}>{t("pr.remove")}</Button>}<Button disabled={busy} onClick={()=>setDraft(null)}>{t("pr.cancel")}</Button><Button type="submit" form="cb-form-customgroups" variant="primary" loading={busy} disabled={failed||busy||checking||!preview||!!preview.error||!draft.name.trim()}>{t("pr.save")}</Button></div> : null} open width={680} closeDisabled={busy} title={t(draft?"cg.editor":"cg.title")} onCancel={()=>{if(!pending.current){if(draft)setDraft(null);else onClose();}}}>
 {draft?<form id="cb-form-customgroups" className="cb-process-form cb-custom-form" onSubmit={e=>{e.preventDefault();if(!preview?.error&&!checking&&preview)void save(baseline.current.some(g=>g.id===draft.id)?baseline.current.map(g=>g.id===draft.id?draft:g):[...baseline.current,draft]);}}>
  <p className="cb-control-note">{t("cg.source")}: {status?.sources?.find(([id])=>id===draft.profile_id)?.[1]??(draft.profile_id===status?.profile_id?status?.profile_name:t("cg.inactive"))}</p>
  <label>{t("cg.name")}<Input autoFocus value={draft.name} maxLength={80} disabled={busy} onChange={e=>setDraft({...draft,name:e.target.value})}/></label>
  <div className="cb-custom-pair"><label>{t("cg.kind")}<Select label={t("cg.kind")} value={draft.kind} disabled={busy} options={[{value:"select",label:t("cg.manual")},{value:"url-test",label:t("cg.auto")}]} onChange={kind=>setDraft({...draft,kind:kind as CustomGroup["kind"]})}/></label><label>{t("cg.membership")}<Select label={t("cg.membership")} value={draft.membership} disabled={busy} options={[{value:"explicit",label:t("cg.explicit")},{value:"filter",label:t("cg.filter")}]} onChange={membership=>setDraft({...draft,membership:membership as CustomGroup["membership"]})}/></label></div>
  {draft.membership==="explicit"?<label>{t("cg.nodes")}<Select multiple label={t("cg.nodes")} selectionLabel={t("cg.nodes")} disabled={busy} value={draft.members} options={[...new Set([...(status?.candidates??[]),...draft.members])].map(value=>({value,label:value}))} onChange={members=>setDraft({...draft,members})}/></label>:<label>{t("cg.filter")}<Input value={draft.filter} disabled={busy} maxLength={256} onChange={e=>setDraft({...draft,filter:e.target.value})}/></label>}
  {draft.kind==="url-test"&&<><p className="cb-control-note">{t("cg.autoNote")}</p><label>{t("cg.url")}<Input value={draft.url} disabled={busy} onChange={e=>setDraft({...draft,url:e.target.value})}/></label><div className="cb-custom-pair"><label>{t("cg.interval")}<Input type="number" min={30} max={86400} value={draft.interval} disabled={busy} onChange={e=>setDraft({...draft,interval:Number(e.target.value)})}/></label><label>{t("cg.tolerance")}<Input type="number" min={1} max={65535} value={draft.tolerance} disabled={busy} onChange={e=>setDraft({...draft,tolerance:Number(e.target.value)})}/></label></div></>}
  <section className="cb-custom-preview" aria-label={t("cg.preview")} aria-busy={checking}><strong>{t("cg.preview")}</strong>{checking?<p role="status">{t("workflow.loading")}</p>:preview?.error?<p role="status">{preview.error}{preview.missing.length>0&&` · ${preview.missing.join(", ")}`}</p>:<p className="cb-selectable">{preview?.members.join(" · ")||"—"}</p>}</section>

 </form>:<section className="cb-process-rules">
  <div className="cb-process-toolbar cb-custom-toolbar"><div className="cb-custom-source"><small>{t("cg.source")}</small><strong>{status?.profile_name??"—"}</strong></div><div className="cb-process-actions"><Button disabled={busy} onClick={()=>void load()}>{t("proxies.refresh")}</Button><Button variant="primary" disabled={!status?.profile_id||!!status.error||!status.candidates.length||failed||busy} onClick={()=>open({id:crypto.randomUUID(),profile_id:status!.profile_id!,name:"",kind:"select",membership:"explicit",members:[],filter:"",url:"https://www.gstatic.com/generate_204",interval:300,tolerance:50})}>{t("cg.add")}</Button></div></div>
  <p className="cb-control-note cb-custom-summary">{t("cg.summary")}</p>
  <details className="cb-custom-help"><summary>{t("cg.help")}</summary><p className="cb-control-note">{t("cg.scope")}</p><p className="cb-control-note">{t("cg.route")}</p></details>
  {failed?<Button onClick={()=>void load()}>{t("home.retryState")}</Button>:status?.error?<p className="cb-control-note">{status.error}</p>:!status?<p role="status">{t("workflow.loading")}</p>:null}
  <div className="cb-custom-list">{status?.groups.length===0&&<p className="cb-control-note">{t("cg.empty")}</p>}{status?.groups.map(g=>{const resolved=status.resolutions.find(([id])=>id===g.id)?.[1];return <div className="cb-custom-list-row" key={g.id}><div><strong>{g.name}</strong><small>{t(g.kind==="select"?"cg.manual":"cg.auto")} · {status.sources?.find(([id])=>id===g.profile_id)?.[1]??t("cg.inactive")}</small><p title={resolved?.members.join(", ")}>{memberText(resolved)}</p></div><Button size="small" disabled={busy} onClick={()=>open(g)}>{t("pr.edit")}</Button></div>;})}</div>
 </section>}
 </Modal>;
}
